import './App.css';
import { Routes, Route, Link } from "react-router-dom";
import Homepage from './pages/Homepage';
import AboutUs from './pages/AboutUs';
import Flights from './pages/Flights';
import UserData from './components/UserData';
import ContactUs from './components/ContactUs';

function App() {
  return (
    <Routes>
        <Route path="/" element={<Homepage />} />
        <Route path="about" element={<AboutUs />} />
        <Route path="destinations" element={<Flights />} />
    </Routes>
    // <ContactUs/>
    // <UserData></UserData>
  );
}

export default App;
