

import React from "react";
import imga from "../images/about-img1.jpg"
import imgb from "../images/about-img2.jpg"
import imgc from "../images/about-img3.jpg"


function About() {
  return (
    <div class="about-sec pc-p-6">
        <div class="container">
            <div class="row align-items-center mc-b-4">
                <div class="col-lg-6">
                    <div class="primary-heading color-dark">
                        <h3 class="mc-b-1 text-uppercase">About Us</h3>
                        <p>Guyway Travel was formed on January 16 1991 in Newark, New Jersey at 157 Alexander Street Newark NJ. Our company is a small family owned travel agency which specializes in personalize travel service to our clients. Our major markets
                            are Guyana, Caribbean, Africa, Central & South America, Europe and the Far East. The owner O’Neill A Glenn was born in Guyana, South America and then migrated to USA in May 1975 where he and his family now call home. O’Neill
                            A Glenn has 17 years of experience in the travel industry and is also a former Continental Airline employee.</p>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="about-img">
                        <figure class="about-img-big">
                            <img src={imga} alt="About Image"/>
                        </figure>
                        <figure class="about-img-small">
                            <img src={imgb} alt="About Image"/>
                        </figure>
                    </div>
                </div>
            </div>
            <div class="row align-items-center">
                <div class="col-lg-6 order-lg-last">
                    <div class="primary-heading color-dark">
                        <p>
                            We have the knowledge and travel experience to help our customers realize their travel dreams, with great deals and the great educated information as always. Guyway Travel specializes in family and group travel, honeymoon and destination weddings, cruises
                            and tours. Our staff has been to many, many destinations and our first hand experience is what sets us above the rest. Our continued education in the travel field keeps us up to date on all of the destinations and properties.
                            Come in and visit us at our location and let us plan your next dream vacation.
                        </p>
                    </div>
                </div>
                <div class="col-lg-6 order-lg-first">
                    <div class="about-img">
                        <figure class="about-img-big">
                            <img src={imgc} alt="About Image"/>
                        </figure>
                    </div>
                </div>
            </div>
        </div>
    </div>
  );
}

export default About;




