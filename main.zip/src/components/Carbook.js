import React from "react";
import img1 from "../images/banner-img.jpg";
function Carbook() {
  return (
    <div class="banner-sec">
    <div class="banner-img">
        <img src={img1} alt="banner-img"/>
    </div>
    <div class="banner-content">
        <div class="container">
            <h2>Car Book</h2>
        </div>
    </div>
</div>
  );
}

export default Carbook;