import React from 'react';

function ContactUs() {

    const [name,setName] = React.useState("");
    const [email,setEmail] = React.useState("");
    const [phone,setPhone] = React.useState("");
    const [message,setMessage] = React.useState("");

    const [data,setData] = React.useState({});
    // const [count,setCount] = React.useState(0)
    // var count = 0;

    return(

        // <div>
        //     <p>{count}</p>
        //     <button onClick={
        //         ()=>{
        //             // count = count + 1;
        //             setCount(count + 1)
        //             console.log(count);
        //         }
        //     }>Click</button>
        // </div>


        <div className="contact-form main-form pc-p-6">

            <div className="container"> 
                <div className="row">
                    <div className="col-lg-6">
                        <div className="form-group">
                            <label>Enter Your Name</label>
                            <input type="text" value={name} className="form-control" 
                            onChange={function(event){
                                setName(event.target.value)
                            }}   
                            placeholder="Enter Your Name"/> 
                        </div>
                    </div>
                    <div className="col-lg-6">
                        <div className="form-group">
                            <label>Enter Your Email</label>
                            <input type="email"  value={email} className="form-control" 
                            onChange={function(event){
                                setEmail(event.target.value)
                            }} 
                            placeholder="Enter Your Email"/> 
                        </div>
                    </div>
                    <div className="col-lg-6">
                        <div className="form-group">
                            <label>Enter Your Number</label>
                            <input type="text" value={phone}  className="form-control" 
                            onChange={function(event){
                                setPhone(event.target.value)
                            }} 
                            placeholder="Enter Your Number"/> 
                        </div>
                    </div>
                    <div className="col-lg-6">
                        <div className="form-group">
                            <label>Enter Your Message</label>
                            <input type="text" value={message} className="form-control" 
                            onChange={function(event){
                                setMessage(event.target.value)
                            }} 
                            placeholder="Enter Your Message"/> 
                        </div>
                    </div>
                    <div className="col-lg-12">
                        <div className="text-center">
                            <button className="primary-btn primary-bg"
                            
                            onClick={
                                function(){
                                   setData(
                                       {
                                           name:name,
                                           email:email,
                                           phone:phone,
                                           message:message
                                       }
                                   )
                                }
                            }

                            >Submit</button>
                        </div>
                    </div>

                </div>

            
             </div>

         
                <h1>{"Welcome "+data.name}</h1>
         

        </div>
    )
}

export default ContactUs;