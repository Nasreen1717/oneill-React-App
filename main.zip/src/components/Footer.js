
import React from "react";
import img1 from "../images/logo.png"

function Footer() {
    return (
<div className="pc-p-6 footerer">
<div className="container">
    <div className="footer-sec">
        <div className="footer pc-p-6">
            <div className="row">
                <div className="col-lg-4">
                    <div className="footer-content primary-heading color-dark">
                        <div className="footer-logo mc-b-2">
                            <img src={img1} alt="Logo"/>
                        </div>
                        <p>It is a long established fact that a reader will be distracted by readable content.</p>
                        <ul className="social-list list-inline mc-t-2">
                            <li className="list-inline-item">
                                <a href="#"> <i className="fa fa-facebook"></i> </a>
                            </li>
                            <li className="list-inline-item">
                                <a href="#"> <i className="fa fa-instagram"></i> </a>
                            </li>
                            <li className="list-inline-item">
                                <a href="#"> <i className="fa fa-twitter"></i> </a>
                            </li>
                            <li className="list-inline-item">
                                <a href="#"> <i className="fa fa-youtube-play"></i> </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div className="col-lg-2">
                    <div className="footer-content">
                        <h3 className="mc-b-2">Quick links</h3>
                        <ul className="footer-list">
                            <li> <a href="index.html"> Home </a> </li>
                            <li> <a href="about.html"> About Us </a> </li>
                            <li> <a href="flight.html"> Flight </a> </li>
                            <li> <a href="cruises.html"> Cruises </a> </li>
                            <li> <a href="hotel.html"> Hotel </a> </li>
                            <li> <a href="car.html"> Car </a> </li>
                        </ul>
                    </div>
                </div>
                <div className="col-lg-2">
                    <div className="footer-content">
                        <h3 className="mc-b-2">Useful links</h3>
                        <ul className="footer-list">
                            <li> <a href="javascript:void(0)"> Contact </a> </li>
                            <li> <a href="javascript:void(0)"> Privacy Policy </a> </li>
                            <li> <a href="javascript:void(0)"> Lorem Ipsum </a> </li>
                            <li> <a href="javascript:void(0)"> Lorem Ipsum </a> </li>
                            <li> <a href="javascript:void(0)"> Lorem Ipsum </a> </li>
                        </ul>
                    </div>
                </div>
                <div className="col-lg-4">
                    <div className="footer-content mc-l-2">
                        <h3 className="mc-b-4">Newsletter </h3>
                        <p>Subscribe in Our Newsletter</p>
                        <form action="" className="subscribe-form mc-t-1">
                            <div className="form-group">
                                <input type="text" className="form-control" placeholder="Enter Your Email"/>
                                <button className="primary-btn primary-bg">Subscribe</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div className="copyright text-center pc-p-2">
            <div className="primary-heading color-light">
                <p>© 2021 All rights reserved.</p>
            </div>
        </div>
    </div>
</div>
</div>
    );
  }
  
  export default Footer;



