import React from "react";
import logo from "../images/logo.png" 
import img1 from "../images/search-icon.png" 
import img2 from "../images/login-icon.png" 
import {Link} from 'react-router-dom'

function Header(props) {
    const page = props.page;
    return (
      <header className="header" id="header">
      <div className="top-row">
          <div className="container">
              <div className="row">
                  <div className="col-lg-6">
                      <ul className="list-inline social-list">
                          <li className="list-inline-item">
                              <Link to="#"> <i className="fa fa-facebook"></i> </Link>
                          </li>
                          <li className="list-inline-item">
                              <Link to="#"> <i className="fa fa-instagram"></i> </Link>
                          </li>
                          <li className="list-inline-item">
                              <Link to="#"> <i className="fa fa-twitter"></i> </Link>
                          </li>
                          <li className="list-inline-item">
                              <Link to="#"> <i className="fa fa-youtube-play"></i> </Link>
                          </li>
                      </ul>
                  </div>
                  <div className="col-lg-6">
                      <ul className="list-inline">
                          <li className="list-inline-item">
                              <Link to="#"> <i className="fa fa-map-marker"></i> 1234 Lorem Ipsum Street 02 </Link>
                          </li>
                          <span> | </span>
                          <li className="list-inline-item">
                              <Link to="#"> <i className="fa fa-phone"></i> (123) 456 7890 </Link>
                          </li>
                      </ul>
                  </div>
              </div>
          </div>
      </div>
      <div className="bottom-row">
          <div className="container">
              <div className="row align-items-center">
                  <div className="col-lg-2 col-12">
                      <div className="logo">
                          <Link to="index.html">
                              <img src={logo} alt="Logo"/>
                          </Link>
                          <div className="hamburger d-block d-lg-none">
                              <div className="hamburger-container">
                                  <span></span>
                                  <span></span>
                                  <span></span>
                              </div>
                          </div>
                      </div>
                  </div>
                  <div className="col-lg-8 col-12">
                      <div className="d-flex align-items-center justify-content-center">
                          <ul className=" navigation-list d-lg-block">
                              <li className={page == 'homepage' ? "active" : ""}><Link to="/">Home</Link></li>
                              <li className={page == 'aboutus' ? "active" : ""}><Link to="/about">About Us</Link></li>
                              <li className={page == 'flights' ? "active" : ""}><Link to="/destinations">Flight</Link></li>
                              <li className=""><Link to="members.html">Cruises </Link></li>
                              <li className=""><Link to="what-we-do.html">Hotel </Link></li>
                              <li className=""><Link to="courses.html">Car</Link></li>
                              <li className=""><Link to="partners.html">Contact</Link></li>
                          </ul>
                      </div>
                  </div>
                  <div className="col-lg-2">
                      <ul className="login-list list-inline">
                          <li className="list-inline-item">
                              <Link to="#"> <img src={img1} alt="Search"/> </Link>
                          </li>
                          <li className="list-inline-item">
                              <Link to="#"> <img src={img2} alt="Login"/> </Link>
                          </li>
                      </ul>
                  </div>
              </div>
          </div>
      </div>
  </header>
    );
  }
  
  export default Header;
  