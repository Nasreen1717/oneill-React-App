import React from "react";
import imga from "../images/package-img1.jpg"
import imgb from "../images/package-img2.jpg"
import imgc from "../images/package-img3.jpg"
import img2 from "../images/map-icon.png"



function Packages(){
    return(
<div className="packages-sec pc-p-6">
        <div className="container">
            <div className="primary-heading color-dark text-center mc-b-4">
                <h3 className="text-uppercase">OUR PACKAGES</h3>
            </div>
            <div className="row">
                <div className="col-lg-4">
                    <div className="package-box">
                        <div className="package-img">
                            <img src={imga} alt="Packages Image"/>
                        </div>
                        <div className="package-content">
                            <h4 className="text-uppercase mc-b-1">heading Here</h4>
                            <p className="mc-b-1"> <span className="icon-img"><img src= {img2} alt="Map Icon"/></span> Lorem Ipsum </p>

                            <div className="package-price">
                                <p>Cultural Relax</p>
                                <span>$ 700</span>
                            </div>
                            <div className="primary-heading color-dark mc-t-1">
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the. </p>
                            </div>
                            <a href="#" className="text-uppercase primary-btn primary-bg">More Detail</a>
                        </div>
                    </div>
                </div>
                <div className="col-lg-4">
                    <div className="package-box">
                        <div className="package-img">
                            <img src={imgb} alt="Packages Image"/>
                        </div>
                        <div className="package-content">
                            <h4 className="text-uppercase mc-b-1">heading Here</h4>
                            <p className="mc-b-1"> <span className="icon-img"><img src={img2} alt="Map Icon"/></span> Lorem Ipsum </p>

                            <div className="package-price">
                                <p>Cultural Relax</p>
                                <span>$ 700</span>
                            </div>
                            <div className="primary-heading color-dark mc-t-1">
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the. </p>
                            </div>
                            <a href="#" className="text-uppercase primary-btn primary-bg">More Detail</a>
                        </div>
                    </div>
                </div>
                <div className="col-lg-4">
                    <div className="package-box">
                        <div className="package-img">
                            <img src={imgc} alt="Packages Image"/>
                        </div>
                        <div className="package-content">
                            <h4 className="text-uppercase mc-b-1">heading Here</h4>
                            <p className="mc-b-1"> <span className="icon-img"><img src={img2} alt="Map Icon"/></span> Lorem Ipsum </p>

                            <div className="package-price">
                                <p>Cultural Relax</p>
                                <span>$ 700</span>
                            </div>
                            <div className="primary-heading color-dark mc-t-1">
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the. </p>
                            </div>
                            <a href="#" className="text-uppercase primary-btn primary-bg">More Detail</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    );
}
export default Packages;



