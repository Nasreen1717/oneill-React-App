import React from "react";
import img1 from "../images/main-banner.jpg"
import img2 from "../images/map-icon.png"
import img3 from "../images/calendar-icon.png"
import img4 from "../images/globe-icon.png"



function Slider() {
    return (
       
        <div className="main-slider">
        <div id="carouselExampleIndicators" className="carousel slide" data-ride="carousel">
        
            <div className="carousel-inner">
                <div className="carousel-item active">
                    <img src={img1} alt="Main Banner"/>
                    <div className="slider-caption">
                        <div className="container">
                            <div className="row">
                                <div className="col-lg-8 col-12 col-center">
                                    <h4>Welcome To</h4>
                                    <h1>Guyway Travel Services
                                    </h1>
                                    <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has. </p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="slider-form">
                        <div className="container">
                            <form action="">
                                <div className="row">
                                    <div className="col-lg-3 p-0">
                                        <div className="form-group">
                                            <input type="text" className="form-control" placeholder="Where To?"/>
                                            <span> <img src={img2} alt="Map Icon"/> </span>
                                        </div>
                                    </div>
                                    <div className="col-lg-3 p-0">
                                        <div className="form-group">
                                            <input type="date" className="form-control" placeholder="Month"/>
                                            <span> <img src={img3} alt="Calendar Icon"/> </span>
                                        </div>
                                    </div>
                                    <div className="col-lg-3 p-0">
                                        <div className="form-group">
                                            <input type="text" className="form-control" placeholder="Travel Type"/>
                                            <span> <img src={img4} alt="Globe Icon"/> </span>
                                        </div>
                                    </div>
                                    <div className="col-lg-3 p-0">
                                        <button className="primary-btn primary-bg text-uppercase">Find Now</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
      
        </div>
    




    );
  }
  
  export default Slider;
  