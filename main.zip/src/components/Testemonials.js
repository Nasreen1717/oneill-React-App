import React from "react";
import img1 from "../images/user-img1.jpg"
import img2 from "../images/user-img2.jpg"
import img3 from "../images/user-img3.jpg"
import Slider from "react-slick";
import "slick-carousel/slick/slick.css"; 
import "slick-carousel/slick/slick-theme.css";




function Testemonials() {
    return (
        <div className="testimonial-sec pc-p-6">
        <div className="container">
            <div className="primary-heading color-dark text-center mc-b-4">
                <h3 className="text-uppercase">Customer Reviews</h3>
            </div>
            <div className="testimonial-slider">
            <Slider 
            dots={true}
            slidesToShow={3}
            speed={500}
            slidesToScroll={1}
            infinite={true}
            
            >
                <div className="testimonial-box">
                    <div className="testimonial-img">
                        <img src={img1} alt="User Image"/>
                    </div>
                    <div className="testimonial-content">
                        <p>Lorem Ipsum is simply dummy text of the printing typesetting industry Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                        <h4>John Deo</h4>
                        <span className="text-uppercase">CEO</span>
                    </div>
                </div>
                <div className="testimonial-box">
                    <div className="testimonial-img">
                        <img src={img2} alt="User Image"/>
                    </div>
                    <div className="testimonial-content">
                        <p>Lorem Ipsum is simply dummy text of the printing typesetting industry Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                        <h4>John Deo</h4>
                        <span className="text-uppercase">CEO</span>
                    </div>
                </div>
                <div className="testimonial-box">
                    <div className="testimonial-img">
                        <img src={img3} alt="User Image"/>
                    </div>
                    <div className="testimonial-content">
                        <p>Lorem Ipsum is simply dummy text of the printing typesetting industry Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                        <h4>John Deo</h4>
                        <span className="text-uppercase">CEO</span>
                    </div>
                </div>
                <div className="testimonial-box">
                    <div className="testimonial-img">
                        <img src={img1} alt="User Image"/>
                    </div>
                    <div className="testimonial-content">
                        <p>Lorem Ipsum is simply dummy text of the printing typesetting industry Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                        <h4>John Deo</h4>
                        <span className="text-uppercase">CEO</span>
                    </div>
                </div>
                <div className="testimonial-box">
                    <div className="testimonial-img">
                        <img src={img1} alt="User Image"/>
                    </div>
                    <div className="testimonial-content">
                        <p>Lorem Ipsum is simply dummy text of the printing typesetting industry Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                        <h4>John Deo</h4>
                        <span className="text-uppercase">CEO</span>
                    </div>
                </div>
                <div className="testimonial-box">
                    <div className="testimonial-img">
                        <img src={img1} alt="User Image"/>
                    </div>
                    <div className="testimonial-content">
                        <p>Lorem Ipsum is simply dummy text of the printing typesetting industry Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
                        <h4>John Deo</h4>
                        <span className="text-uppercase">CEO</span>
                    </div>
                </div>
        </Slider>
            </div>
        </div>
    </div>

    );
  }
  
  export default Testemonials;
  





