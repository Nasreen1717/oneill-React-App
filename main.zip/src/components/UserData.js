import React from 'react';
function UserData(){

    const [userData, setUserData] = React.useState({});
    const [loading, setLoading] = React.useState(true);

    async function getUserData(){
        fetch('https://api.randomuser.me/')
        .then(response => response.json())
        .then(data => {
            setUserData(data.results[0])
            setLoading(false);
        })
        .catch(e => console.log(e))
    }

    React.useEffect(()=>{
        getUserData()
    },[])

    return(
        
        <div>
            {
              loading == true ? <p>Loading</p> :
              <div>

              <h1>User Data</h1>
              <p>Name : {userData.name.first}</p>
              <p>Age : {userData.dob.age}</p>
              </div>
            }
            
        </div>
    )
}

export default UserData;