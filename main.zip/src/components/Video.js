import React from "react";


function Video() {
    return (
  
  
<div className="video-sec pc-p-6">
<div className="text-center video-content">
    <h3 className="mc-b-1">Traveling Highlights</h3>
    <h4>Your New Traveling Idea</h4>
    <a href="#"><i className="fa fa-play" aria-hidden="true"></i></a>
</div>
</div>
    );
  }
  
  export default Video;


