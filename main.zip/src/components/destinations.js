
import React from "react";
import img1 from "../images/destination-img1.jpg"




function Destinations() {

    const destinations = [
        {
            h3 : "Europe",
            h4 : "3 Packages",
            img : img1
        },
        {
            h3 : "Asia",
            h4 : "10 Packages",
            img : img1
        },
        {
            h3 : "Thailand",
            h4 : "1 Packages",
            img : img1
        },
        {
            h3 : "Singapore",
            h4 : "2 Packages",
            img : img1
        },
        {
            h3 : "Turkey",
            h4 : "5 Packages",
            img : img1
        },
        {
            h3 : "Saudi Arabia",
            h4 : "100 Packages",
            img : img1
        },
    ]

    return (
        <div className="destination-sec pc-p-6">
        <div className="container">
            <div className="primary-heading color-dark mc-b-4 text-center">
                <h3 className="text-uppercase">OUR DESTINATIONS</h3>
            </div>
            <div className="row">

                {

                    destinations.map((destination) => {
                        return(
                            <div className="col-lg-4">
                                <div className="destination-box">
                                    <div className="destination-img">
                                        <a href="#"><img src={destination.img} alt="Destination"/></a>
                                    </div>
                                    <div className="destination-content">
                                        <h3 className="text-uppercase">{destination.h3}</h3>
                                        <h4 className="text-uppercase">{destination.h4}</h4>
                                    </div>
                                </div>
                            </div>
                        )
                    })


                }

                



            </div>
        </div>
    </div>

    );
  }
  
  export default Destinations;
  