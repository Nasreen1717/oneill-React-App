import React from 'react';
import About from '../components/About';
import Footer from '../components/Footer';
import Header from '../components/Header';

function AboutUs(){
    return(
        <div>
            <Header page="aboutus"/>
            <About/>
            <Footer/>
        </div>
    )
}

export default AboutUs;