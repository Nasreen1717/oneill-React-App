import React from 'react';
import Destinations from '../components/destinations';
import Footer from '../components/Footer';
import Header from '../components/Header';

function Flights(){
    return(
        <div>
            <Header page="flights"/>
            <Destinations/>
            <Footer/>
        </div>
    )
}

export default Flights;