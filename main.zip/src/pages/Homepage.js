
import Header from '../components/Header';
import Slider from '../components/Slider';
import Destinations from '../components/destinations';
import Aboutus from '../components/Aboutus';
import Packages from '../components/Packages';
import Video from '../components/Video';
import Testemonials from '../components/Testemonials';
import Footer from '../components/Footer';



function Homepage() {
  return (
    <div>


<Header page="homepage"/>
<Slider/>
<Destinations/>
<Aboutus/>
<Packages/>
<Video/>
<Testemonials/>
<Footer/>

    </div>
  );
}

export default Homepage;
